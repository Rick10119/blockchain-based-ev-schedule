
close;
nofStations = 10;
nofSlots = 6;
c = nofSlots * nofStations; % Slots
mu = 4;
tau = 30;

w_GGc = [];
w_GGc_1 = [];
h = 0.1;


%%
for rho = 0.5: h : 1-h
    
    sigma2a = 1;
    sigma2c = 1;
    w_GGc = [w_GGc, tau + tau * (rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    w_GGc_1 = [w_GGc_1, tau + tau * (nofStations * rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    
    
end
% ��ȡ���ڵ�ϵͳ
% load('sim-result-l1.mat');
% t_queue =  [t0 * t_davidson,t0 * t_MMn,t0 * t_MMnm,expectTime'];
rho = 0.5:h:1 - h;
linewidth = 2;
% lambda = lambda * 3;
% plot(lambda,t0 * t_davidson,'LineWidth',linewidth);
% hold on
% plot(lambda,t0 * t_MMn,'LineWidth',linewidth);

hold on
plot(rho, w_GGc,'LineWidth',linewidth);

hold on
plot(rho, w_GGc_1,'LineWidth',linewidth);
%
% hold on
% plot(lambda,expectTime','LineWidth',linewidth);

% hold on
% plot(rho,delta_c,'LineWidth',linewidth);



%%

t1 = title('waiting time','FontSize',24);
x1 = xlabel('rho','FontSize',18);          %����������tex����
y1 = ylabel('w','FontSize',18);

% legend('t-Davidson','t-MMn','t-MMnm',"t-sim");
legend('w_GGc','w_GGc_1');
saveas(gcf,'queue-time.jpg'); %���浱ǰ���ڵ�ͼ��66666666



  