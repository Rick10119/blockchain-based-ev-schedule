

%% ��ͼ
%% G/G/c ����ֵ
queueing_time_test;

linewidth = 1.3;

%% 9�ڵ�ϵͳ����ֵ
load('sim-distance-best-l9.mat');
rho = 0.8:0.2:3;
waitTime = expectTime;

plot(9*lambda, waitTime,'LineWidth',linewidth);
hold on;


% ��ȡ9�ڵ�ϵͳ
%% 9վ��ֱ��ȥ����ĳ��վ


%% ��queryTime��9վ
% load('sim-query1.mat');
% lambda = 0.8:0.2:1.4;
% waitTime = expectTime;
% load('sim-query2.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,1.6:0.2:2.2];
% load('sim-query3.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,2.4:0.2:2.6];
% load('sim-query4.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,2.8:0.2:3.0];
load('sim-query-l9-over.mat');
lambda = 0.8:0.2:4;
plot(9 * lambda, expectTime,'LineWidth',linewidth);

%% ֻ������Ŷ�ʱ��

% load('sim-query-l9-tf.mat');
% lambda = 1:0.4:3;
% plot(9 * lambda, expectTime,'LineWidth',linewidth);
% hold on;

%% ֻ������
% load('sim-query-l9-df2.mat');
% lambda = 1:0.4:3;
% plot(9 * lambda, expectTime,'LineWidth',linewidth);

%% ����������
load('sim-queue-test-l9-15.mat');
lambda = 1:2:27;
plot(lambda, expectTime,'LineWidth',linewidth);

load('sim-queue-test-l9-60.mat');
lambda = 1:2:27;
plot(lambda(1:end-1), diff(expectTime),'LineWidth',linewidth);
%%

t1 = title('t-queue','FontSize',24);
x1 = xlabel('lambda','FontSize',18);          %����������tex����
y1 = ylabel('t_s','FontSize',18);

% legend('t-Davidson','t-MMn','t-MMnm',"t-sim");
legend("t-sim-best-9","t-query","t-sim-9-15","t-sim-9-60");
saveas(gcf,'queue-time-9-df-qt.jpg'); %���浱ǰ���ڵ�ͼ��66666666
