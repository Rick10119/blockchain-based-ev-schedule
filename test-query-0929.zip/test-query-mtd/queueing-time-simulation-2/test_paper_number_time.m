clc;clear;

linewidth = 2;
t_slot = 1:12;


%% mtd ���ı����ʱ��
load("day-mtd");
% expectTime = mean(expect_arrive_number_slot);
expectTime = mean(expect_chargingTime_slot + expect_roadTime);
expectTime = [expectTime,expectTime(12)];
stairs(expectTime,'--m','LineWidth',linewidth);
hold on;

%% û�м۸���� ct-np
load("day-ct-np");
% expectTime = mean(expect_arrive_number_slot);
expectTime = mean(expect_chargingTime_slot + expect_roadTime);
expectTime = [expectTime,expectTime(12)];
stairs(expectTime,':b','LineWidth',linewidth);
%% ���Ȩ���� ct-p
load("day-ct-p");
% expectTime = mean(expect_arrive_number_slot);
expectTime = mean(expect_chargingTime_slot + expect_roadTime);
expectTime = [expectTime,expectTime(12)];
stairs(expectTime,'-r','LineWidth',linewidth);

%% ��������
m=linspace(datenum('1:00','HH:MM'),datenum('25:00','HH:MM'),7);
set(gca,'xtick',1:2:13);
set(gca, 'xlim',[1 13]);
% set(gca, 'ylim',[9 13]);
for n=1:length(m)
  tm{n}=datestr(m(n),'HH:MM');
end
set(gca,'xticklabel',tm);
set(gca, "YGrid", "on");
legend("MTD", "COS-NP", "COS");
x1 = xlabel('ʱ��','FontSize',18);          %����������tex����
y1 = ylabel('ƽ���г�ʱ�䣨���ӣ�','FontSize',18);
set(gca,'linewidth',1.5,'fontsize',18);
saveas(gcf,'mean_time.jpg'); %���浱ǰ���ڵ�ͼ��66666666
