
% ����3���վ�ĸ������ߣ�ֻ���Ǿ��롢mmnm����ֵ��mm9n9m����
clc;clear;
close;
nofStations = 9;
nofSlots = 6;
c = nofSlots * nofStations; % Slots
mu = 4;
tau = 30;

w_GGc = [];
w_GGc_1 = [];
h = 0.1;


%%
for rho = 0.5: h : 1-h
    
    sigma2a = 1;
    sigma2c = 0.1481;
    w_GGc = [w_GGc, tau + tau * (rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    w_GGc_1 = [w_GGc_1, tau + tau * (nofStations * rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    
    
end


%% ��ͼ

rho = 0.5: h :1 - h;

linewidth = 1.3;
%% ����ֵ

hold on
plot(rho, w_GGc_1,'LineWidth',linewidth);


%% 9�ڵ�ϵͳ����ֵ
% load('sim-l1-54.mat');
% lambda = 0.5:0.1:2.9;
% waitTime = expectTime;
% 
% plot(9*lambda, waitTime,'LineWidth',linewidth);
% hold on;
% legend("davidson","l1-54");

% ��ȡ9�ڵ�ϵͳ
%% 9վ��ֱ��ȥ����ĳ��վ
% load('sim-l9-df.mat');
% lambda = 0.5:0.1:2.9;
% waitTime = expectTime;
% 
% plot(9*lambda, waitTime,'LineWidth',linewidth);
% hold on;

%% ��queryTime��9վ
% load('sim-query1.mat');
% lambda = 0.8:0.2:1.4;
% waitTime = expectTime;
% load('sim-query2.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,1.6:0.2:2.2];
% load('sim-query3.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,2.4:0.2:2.6];
% load('sim-query4.mat');
% waitTime = [waitTime,expectTime];
% lambda = [lambda,2.8:0.2:3.0];
load('sim-l9-qt.mat');
lambda = 0.5:0.1:2.9;
rho = lambda / 3;
plot(rho, expectTime,'LineWidth',linewidth);

%% ֻ������Ŷ�ʱ��

% load('sim-query-l9-tf.mat');
% lambda = 1:0.4:3;
% plot(9 * lambda, expectTime,'LineWidth',linewidth);
% hold on;



%% ����������
load('sim-n.mat');
lambda = 1:1:26;
rho = lambda / 27;
plot(rho, expectTime,'LineWidth',linewidth);


% load('sim-n-1.mat');
% lambda = 1:1:26;
% plot(lambda, expectTime,'LineWidth',linewidth);

%%

t1 = title('t-queue','FontSize',24);
x1 = xlabel('lambda','FontSize',18);          %����������tex����
y1 = ylabel('t_s','FontSize',18);

% legend('t-Davidson','t-MMn','t-MMnm',"t-sim");
% legend("davidson","l1-54","t-sim-qt","t-sim-n","t-sim-n-1");
legend('w_GGc',"t-sim-qt","t-sim-n");
saveas(gcf,'queue-time-9-df-qt.jpg'); %���浱ǰ���ڵ�ͼ��66666666
