% to give the J
close;

% ����ֵ
queueing_time_test;

% ��ȡ���ڵ�ϵͳ

lambda = 0.5:h:n*mu - h;
rho = lambda / n*mu
linewidth = 2;

plot(lambda,t0 * t_davidson,'LineWidth',linewidth);
hold on
plot(lambda,t0 * t_MMn,'LineWidth',linewidth);

% hold on
% plot(lambda,t0 * t_MMnm,'LineWidth',linewidth);

% hold on
% plot(lambda,t0 * t_MMnm1,'LineWidth',linewidth);
% 
% hold on
% plot(lambda,expectTime','LineWidth',linewidth);
load('sim-l1-6.mat');
lambda = 0.5:0.1:2.9;
plot(lambda,expectTime,'LineWidth',linewidth);


% hold on
% plot(lambda,delta_c,'LineWidth',linewidth);



%%

t1 = title('t-queue','FontSize',24);
x1 = xlabel('lambda','FontSize',18);          %����������tex����
y1 = ylabel('t_s','FontSize',18);

% legend('t-Davidson','t-MMn','t-MMnm',"t-sim");
legend('t-davidson','t-MMn',"t-sim-1");
saveas(gcf,'queue-time.jpg'); %���浱ǰ���ڵ�ͼ��66666666



  