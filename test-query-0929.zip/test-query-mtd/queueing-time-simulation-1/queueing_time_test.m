% to give the J
close;
nofStations = 10;
nofSlots = 6;
c = nofSlots * nofStations; % Slots
mu = 4;
tau = 30;
J = 0.04;

t_davidson = [];
w_GGc = [];
w_GGc_1 = [];
t_MMnm = [];
t_MMnm1 = [];
delta_c = [];
h = 0.1;


%%
for rho = 0.5: h : 1-h
    
    sigma2a = 1;
    sigma2c = 1;
    w_GGc = [w_GGc, tau * (rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    w_GGc_1 = [w_GGc_1, tau * (nofStations * rho/c/(1-rho)) * (sigma2a + sigma2c)/2];
    
    % G/G/c
%     temp_k = zeros(1, c);
%     for k = 0:c-1
%         temp_k(k+1) = ro1^k/(factorial(k));
%     end
%     
%     % exact
%     p0 = 1/ (sum(temp_k)+ ro1^c/factorial(c)/(1-ro));
%     W_q_MMn = ro1^c*p0/(mu*c*factorial(c)*(1-ro)^2);
    
    % approximation
    %     W_q_MMn = tau * (ro ^((2*m+2)^)))
    
    
    
    
    
    %M/M/n/m
    
    %     t_MMnm = [t_MMnm;1/mu + W_q_MMnm*0.8];
    %     t_MMnm = [t_MMnm;tq_MMnm(lambda, mu, n, m)];
    %     t_MMnm1 = [t_MMnm1;tq_MMnm(lambda, mu, n-1, m-1)];
    
%     delta_c = [delta_c;(tq_MMnm(rho, mu, c-1, m-1) - tq_MMnm(rho, mu, c, m)) * rho];
    
end
% ��ȡ���ڵ�ϵͳ
% load('sim-result-l1.mat');
% t_queue =  [t0 * t_davidson,t0 * t_MMn,t0 * t_MMnm,expectTime'];
rho = 0.5:h:1 - h;
linewidth = 2;
% lambda = lambda * 3;
% plot(lambda,t0 * t_davidson,'LineWidth',linewidth);
% hold on
% plot(lambda,t0 * t_MMn,'LineWidth',linewidth);

hold on
plot(rho, w_GGc,'LineWidth',linewidth);

hold on
plot(rho, w_GGc_1,'LineWidth',linewidth);
%
% hold on
% plot(lambda,expectTime','LineWidth',linewidth);

% hold on
% plot(rho,delta_c,'LineWidth',linewidth);



%%

t1 = title('waiting time','FontSize',24);
x1 = xlabel('rho','FontSize',18);          %����������tex����
y1 = ylabel('w','FontSize',18);

% legend('t-Davidson','t-MMn','t-MMnm',"t-sim");
legend('w_GGc','w_GGc_1');
saveas(gcf,'queue-time.jpg'); %���浱ǰ���ڵ�ͼ��66666666



  