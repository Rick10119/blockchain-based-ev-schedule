/*
 * Copyright 2010 Aalto University, ComNet
 * Released under GPLv3. See LICENSE.txt for details.
 */
package core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

import movement.MovementModel;
import movement.Path;
import movement.StationMovement;
import routing.MessageRouter;
import routing.util.RoutingInfo;

/**
 * A DTN capable host.
 */
public class DTNHost implements Comparable<DTNHost> {
    private static int nextAddress = 0;
    private int address;

    private Coord location;    // where is the host
    private Coord destination;    // where is it going

    private MessageRouter router;
    private MovementModel movement;
    private Path path;
    private double speed;
    private double nextTimeToMove;
    private String name;
    private List<MessageListener> msgListeners;
    private List<MovementListener> movListeners;
    private List<NetworkInterface> net;
    private ModuleCommunicationBus comBus;
    private SimScenario scenario;
    /**
     * common rng for all movement models in the simulation
     */
    protected static Random rng = new Random();

    /**
     * 充电相关字段
     */
    private double energyToCharge;//要充的电量，初始化均值30kwh
    private double roadTime, beta_SDL, beta_SDE, beta_TT;// 成本qt/效用ct
    private int jmax;
    private double price;//充电权价格

    public static final double chargingRate = 60.0 / 3600.0;//充电速率,60kW,换算为秒钟
    private DTNHost chargingHost = null;//选择的充电站的host句柄，初始化为null
    /**
     * 充电状态：-2表示还没开始查询时间。-1空白，0表示在路上，1代表还没充/刚到达充电站，2代表排队；3代表正在充；4代表充完，5结束
     * 如果排队失败，那么从1回到-1.一旦进入2,那就会到3, 4。（正常情况不会排队失败）
     * 不考虑充一半电的情况
     */
    private int chargingStatus;

    static {
        DTNSim.registerForReset(DTNHost.class.getCanonicalName());
        reset();
    }

    /**
     * Creates a new DTNHost.
     *
     * @param msgLs        Message listeners
     * @param movLs        Movement listeners
     * @param groupId      GroupID of this host
     * @param interf       List of NetworkInterfaces for the class
     * @param comBus       Module communication bus object
     * @param mmProto      Prototype of the movement model of this host
     * @param mRouterProto Prototype of the message router of this host
     */
    public DTNHost(List<MessageListener> msgLs,
                   List<MovementListener> movLs,
                   String groupId, List<NetworkInterface> interf,
                   ModuleCommunicationBus comBus,
                   MovementModel mmProto, MessageRouter mRouterProto, SimScenario scenario) {
        this.comBus = comBus;
        this.location = new Coord(0, 0);
        this.address = getNextAddress();
        this.name = groupId + address;
        this.net = new ArrayList<NetworkInterface>();
        this.scenario = scenario;
        this.energyToCharge = 10.0 + 40.0 * rng.nextDouble();//初始需要充的电量
        this.chargingStatus = -2;//还没开始查询时间

        for (NetworkInterface i : interf) {
            NetworkInterface ni = i.replicate();
            ni.setHost(this);
            net.add(ni);
        }

        this.msgListeners = msgLs;
        this.movListeners = movLs;

        // create instances by replicating the prototypes
        this.movement = mmProto.replicate();
        this.movement.setComBus(comBus);
        this.movement.setHost(this);
        setRouter(mRouterProto.replicate());

        this.location = this.movement.getInitialLocation();

        // 设置启动时间
        this.nextTimeToMove = this.movement.nextPathAvailable();
        this.path = null;

        this.report();
    }


    /**
     * 报告
     */
    public void report() {
        if (this.movListeners != null) {
            for (MovementListener l : this.movListeners) {
                l.newDestination(this, this.destination, this.speed);
            }
        }
    }

    /**
     * 返回这里初始化的world。这将在其实现DTNSimGUI中被调用。
     *
     * @return 这里的world
     */
    public World getWorld() {
        return this.scenario.getWorld();
    }

    public double getEnergyToCharge() {
        return this.energyToCharge;
    }

    public double[] getCost() {
        return new double[]{roadTime, beta_SDL, beta_SDE, beta_TT, energyToCharge, jmax};
    }

    public void setCost(double roadTime, double beta_SDL, double beta_SDE, double beta_TT, int jmax) {
        this.roadTime = roadTime;
        this.beta_SDL = beta_SDL;
        this.beta_SDE = beta_SDE;
        this.beta_TT = beta_TT;
        this.jmax = jmax;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }

    public SimScenario getScenario() {
        return this.scenario;
    }

    /**
     * 返回这里初始化的Movement。这将在其实现ChargingMovement中被调用。
     *
     * @return 这里的Movement
     */
    public MovementModel getMovement() {
        return this.movement;
    }

    public String getName() {
        return this.name;
    }

    public void setChargingHost(DTNHost chargingHost) {
        this.chargingHost = chargingHost;
    }

    public DTNHost getChargingHost() {
        return this.chargingHost;
    }

    public void setChargingStatus(int status) {
        this.chargingStatus = status;
    }

    public int getChargingStatus() {
        return this.chargingStatus;
    }


    /**
     * Moves the node towards the next waypoint or waits if it is
     * not time to move yet
     *
     * @param timeIncrement How long time the node moves
     */
    public void move(double timeIncrement) {
        double possibleMovement;
        double distance;
        double dx, dy;


        /** 更新充电排队  */
        if (this.chargingStatus == 3) { //正在充

            // 充电未完成
            if (this.energyToCharge >= timeIncrement * chargingRate) {
            // 更新充电状态
                this.energyToCharge -= timeIncrement * chargingRate;
            } else { // 充电完成
                this.energyToCharge = 0.0;
                // 调用充电站队列更新，出队
                ((StationMovement) this.chargingHost.movement).getStationQueue().deQueue(this);

                // 更新车辆状态，充完了
                this.chargingStatus = 4;

                // 向listener报告位置等信息-充电完成-这时候ev为状态4
                this.report();

                // 结束状态
                this.chargingStatus = 5;
            }

            // 如果还在充电那么不执行移动；充满电也下一个时间步长才移动
            return;

        }

        // 尚在等待中
        if (!isMovementActive() || SimClock.getTime() < this.nextTimeToMove) {
            return;
        }
        // 尚未选择路线
        if (this.destination == null) {
            if (!setNextWaypoint()) {
                return;
            }
        }

        possibleMovement = timeIncrement * speed;
        distance = this.location.distance(this.destination);

        while (possibleMovement >= distance) {
            // node can move past its next destination
            this.location.setLocation(this.destination); // snap to destination

            /** 进入充电状态-位置，到达充电站.如果尚没有充电，那么进入充电状态，并开始等待 */

            // 下一个节点位置和充电站位置重合（也就是下一步就到充电站）
            if (this.chargingHost != null &&
                    this.destination.equals(this.chargingHost.getLocation())) {

                if (this.chargingStatus == 0) {

                    this.chargingStatus = 1;

                    // 向listener报告位置等信息-到达充电站
                    this.report();

                    // 设置电动汽车状态，开始排队。因为之前考虑可能排队失败，现在不用报告了
                    this.chargingStatus = 2;

                    //设置充电站状态，入队.返回值为true表示入队成功。在upDate中设置状态为 3并报告，表示开始充电
                    ((StationMovement) this.chargingHost.getMovement()).
                            getStationQueue().upDate();

                    return;
                }
            }


            // 设置下一个到达地点
            possibleMovement -= distance;
            // 如果还在充电站没充完，不用设置

            // TODO: 如果排不进去怎么办
            if (!setNextWaypoint()) { // get a new waypoint
                return; // no more waypoints left
            }

            distance = this.location.distance(this.destination);

        }

        // move towards the point for possibleMovement amount
        dx = (possibleMovement / distance) * (this.destination.getX() -
                this.location.getX());
        dy = (possibleMovement / distance) * (this.destination.getY() -
                this.location.getY());

        this.location.translate(dx, dy);
    }

    /**
     * Sets the next destination and speed to correspond the next waypoint
     * on the path.
     *
     * @return True if there was a next waypoint to set, false if node still
     * should wait
     */
    private boolean setNextWaypoint() {

        if (path == null) {
            path = movement.getPath();
        }

        if (path == null || !path.hasNext()) {
            //
            this.path = null;
            return false;
        }

        this.destination = path.getNextWaypoint();
        this.speed = path.getSpeed();

        // 向listener报告位置等信息
//        this.report();

        return true;
    }

    /**
     * Returns a new network interface address and increments the address for
     * subsequent calls.
     *
     * @return The next address.
     */
    private synchronized static int getNextAddress() {
        return nextAddress++;
    }

    /**
     * Reset the host and its interfaces
     */
    public static void reset() {
        nextAddress = 0;
    }

    /**
     * Returns true if this node is actively moving (false if not)
     *
     * @return true if this node is actively moving (false if not)
     */
    public boolean isMovementActive() {
        return this.movement.isActive();
    }

    /**
     * Returns true if this node's radio is active (false if not)
     *
     * @return true if this node's radio is active (false if not)
     */
    public boolean isRadioActive() {
        /* TODO: make this work for multiple interfaces */
        return this.getInterface(1).isActive();
    }

    /**
     * Set a router for this host
     *
     * @param router The router to set
     */
    private void setRouter(MessageRouter router) {
        router.init(this, msgListeners);
        this.router = router;
    }

    /**
     * Returns the router of this host
     *
     * @return the router of this host
     */
    public MessageRouter getRouter() {
        return this.router;
    }

    /**
     * Returns the network-layer address of this host.
     */
    public int getAddress() {
        return this.address;
    }

    /**
     * Returns this hosts's ModuleCommunicationBus
     *
     * @return this hosts's ModuleCommunicationBus
     */
    public ModuleCommunicationBus getComBus() {
        return this.comBus;
    }

    /**
     * Informs the router of this host about state change in a connection
     * object.
     *
     * @param con The connection object whose state changed
     */
    public void connectionUp(Connection con) {
        this.router.changedConnection(con);
    }

    public void connectionDown(Connection con) {
        this.router.changedConnection(con);
    }

    /**
     * Returns a copy of the list of connections this host has with other hosts
     *
     * @return a copy of the list of connections this host has with other hosts
     */
    public List<Connection> getConnections() {
        List<Connection> lc = new ArrayList<Connection>();

        for (NetworkInterface i : net) {
            lc.addAll(i.getConnections());
        }

        return lc;
    }

    /**
     * Returns the current location of this host.
     *
     * @return The location
     */
    public Coord getLocation() {
        return this.location;
    }

    /**
     * Returns the Path this node is currently traveling or null if no
     * path is in use at the moment.
     *
     * @return The path this node is traveling
     */
    public Path getPath() {
        return this.path;
    }


    /**
     * Sets the Node's location overriding any location set by movement model
     *
     * @param location The location to set
     */
    public void setLocation(Coord location) {
        this.location = location.clone();
    }

    /**
     * Sets the Node's name overriding the default name (groupId + netAddress)
     *
     * @param name The name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the messages in a collection.
     *
     * @return Messages in a collection
     */
    public Collection<Message> getMessageCollection() {
        return this.router.getMessageCollection();
    }

    /**
     * Returns the number of messages this node is carrying.
     *
     * @return How many messages the node is carrying currently.
     */
    public int getNrofMessages() {
        return this.router.getNrofMessages();
    }

    /**
     * Returns the buffer occupancy percentage. Occupancy is 0 for empty
     * buffer but can be over 100 if a created message is bigger than buffer
     * space that could be freed.
     *
     * @return Buffer occupancy percentage
     */
    public double getBufferOccupancy() {
        double bSize = router.getBufferSize();
        double freeBuffer = router.getFreeBufferSize();
        return 100 * ((bSize - freeBuffer) / bSize);
    }

    /**
     * Returns routing info of this host's router.
     *
     * @return The routing info.
     */
    public RoutingInfo getRoutingInfo() {
        return this.router.getRoutingInfo();
    }

    /**
     * Returns the interface objects of the node
     */
    public List<NetworkInterface> getInterfaces() {
        return net;
    }

    /**
     * Find the network interface based on the index
     */
    public NetworkInterface getInterface(int interfaceNo) {
        NetworkInterface ni = null;
        try {
            ni = net.get(interfaceNo - 1);
        } catch (IndexOutOfBoundsException ex) {
            throw new SimError("No such interface: " + interfaceNo +
                    " at " + this);
        }
        return ni;
    }

    /**
     * Find the network interface based on the interfacetype
     */
    protected NetworkInterface getInterface(String interfacetype) {
        for (NetworkInterface ni : net) {
            if (ni.getInterfaceType().equals(interfacetype)) {
                return ni;
            }
        }
        return null;
    }

    /**
     * Force a connection event
     */
    public void forceConnection(DTNHost anotherHost, String interfaceId,
                                boolean up) {
        NetworkInterface ni;
        NetworkInterface no;

        if (interfaceId != null) {
            ni = getInterface(interfaceId);
            no = anotherHost.getInterface(interfaceId);

            assert (ni != null) : "Tried to use a nonexisting interfacetype " + interfaceId;
            assert (no != null) : "Tried to use a nonexisting interfacetype " + interfaceId;
        } else {
            ni = getInterface(1);
            no = anotherHost.getInterface(1);

            assert (ni.getInterfaceType().equals(no.getInterfaceType())) :
                    "Interface types do not match.  Please specify interface type explicitly";
        }

        if (up) {
            ni.createConnection(no);
        } else {
            ni.destroyConnection(no);
        }
    }

    /**
     * for tests only --- do not use!!!
     */
    public void connect(DTNHost h) {
        Debug.p("WARNING: using deprecated DTNHost.connect(DTNHost)" +
                "Use DTNHost.forceConnection(DTNHost,null,true) instead");
        forceConnection(h, null, true);
    }

    /**
     * Updates node's network layer and router.
     *
     * @param simulateConnections Should network layer be updated too
     */
    public void update(boolean simulateConnections) {
        if (!isRadioActive()) {
            // Make sure inactive nodes don't have connections
            tearDownAllConnections();
            return;
        }

        if (simulateConnections) {
            for (NetworkInterface i : net) {
                i.update();
            }
        }
        this.router.update();
    }

    /**
     * Tears down all connections for this host.
     */
    private void tearDownAllConnections() {
        for (NetworkInterface i : net) {
            // Get all connections for the interface
            List<Connection> conns = i.getConnections();
            if (conns.size() == 0) continue;

            // Destroy all connections
            List<NetworkInterface> removeList =
                    new ArrayList<NetworkInterface>(conns.size());
            for (Connection con : conns) {
                removeList.add(con.getOtherInterface(i));
            }
            for (NetworkInterface inf : removeList) {
                i.destroyConnection(inf);
            }
        }
    }


    /**
     * Sends a message from this host to another host
     *
     * @param id Identifier of the message
     * @param to Host the message should be sent to
     */
    public void sendMessage(String id, DTNHost to) {
        this.router.sendMessage(id, to);
    }

    /**
     * Start receiving a message from another host
     *
     * @param m    The message
     * @param from Who the message is from
     * @return The value returned by
     * {@link MessageRouter#receiveMessage(Message, DTNHost)}
     */
    public int receiveMessage(Message m, DTNHost from) {
        int retVal = this.router.receiveMessage(m, from);

        if (retVal == MessageRouter.RCV_OK) {
            m.addNodeOnPath(this);    // add this node on the messages path
        }

        return retVal;
    }

    /**
     * Requests for deliverable message from this host to be sent trough a
     * connection.
     *
     * @param con The connection to send the messages trough
     * @return True if this host started a transfer, false if not
     */
    public boolean requestDeliverableMessages(Connection con) {
        return this.router.requestDeliverableMessages(con);
    }

    /**
     * Informs the host that a message was successfully transferred.
     *
     * @param id   Identifier of the message
     * @param from From who the message was from
     */
    public void messageTransferred(String id, DTNHost from) {
        this.router.messageTransferred(id, from);
    }

    /**
     * Informs the host that a message transfer was aborted.
     *
     * @param id             Identifier of the message
     * @param from           From who the message was from
     * @param bytesRemaining Nrof bytes that were left before the transfer
     *                       would have been ready; or -1 if the number of bytes is not known
     */
    public void messageAborted(String id, DTNHost from, int bytesRemaining) {
        this.router.messageAborted(id, from, bytesRemaining);
    }

    /**
     * Creates a new message to this host's router
     *
     * @param m The message to create
     */
    public void createNewMessage(Message m) {
        this.router.createNewMessage(m);
    }

    /**
     * Deletes a message from this host
     *
     * @param id   Identifier of the message
     * @param drop True if the message is deleted because of "dropping"
     *             (e.g. buffer is full) or false if it was deleted for some other reason
     *             (e.g. the message got delivered to final destination). This effects the
     *             way the removing is reported to the message listeners.
     */
    public void deleteMessage(String id, boolean drop) {
        this.router.deleteMessage(id, drop);
    }

    /**
     * Returns a string presentation of the host.
     *
     * @return Host's name
     */
    public String toString() {
        return name;
    }

    /**
     * Checks if a host is the same as this host by comparing the object
     * reference
     *
     * @param otherHost The other host
     * @return True if the hosts objects are the same object
     */
    public boolean equals(DTNHost otherHost) {
        return this == otherHost;
    }

    /**
     * Compares two DTNHosts by their addresses.
     *
     * @see Comparable#compareTo(Object)
     */
    public int compareTo(DTNHost h) {
        return this.getAddress() - h.getAddress();
    }

}
