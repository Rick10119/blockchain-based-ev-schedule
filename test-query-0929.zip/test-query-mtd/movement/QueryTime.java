package movement;

import core.DTNHost;
import core.Settings;
import core.SimClock;
import movement.map.DijkstraPathFinder;
import movement.map.MapNode;
import movement.map.PointsOfInterest;

import javax.swing.text.html.StyleSheet;
import java.util.List;
import java.util.Random;

public class QueryTime extends MapBasedMovement {

    /**
     * the Dijkstra shortest path finder
     */
    private DijkstraPathFinder pathFinder;
    /**
     * Points Of Interest handler
     */
    private PointsOfInterest pois;
    /**
     * The special setting of the EV
     */
    private double beta_TT;// 北京市每小时24元
    private double TT;// 总共的时间
    private int jmax;

    // 构造器和父类一样。需要覆盖：选择路径的方法

    /**
     * Creates a new movement model based on a Settings object's settings.
     *
     * @param settings The Settings object where the settings are read from
     */
    public QueryTime(Settings settings) {
        super(settings);

        this.pathFinder = new DijkstraPathFinder(getOkMapNodeTypes());
        this.pois = new PointsOfInterest(getMap(), getOkMapNodeTypes(),
                settings, rng);
        this.backAllowed = true;
        this.beta_TT = -12.0 ;

    }

    /**
     * Copy constructor.
     *
     * @param mbm The ChargingMovement prototype to base
     *            the new object to
     */
    public QueryTime(QueryTime mbm) {
        super(mbm);
        this.pathFinder = mbm.pathFinder;
        this.pois = mbm.pois;
        this.beta_TT = mbm.beta_TT;
    }

    /**
     * Returns a sim time when the next path is available. This implementation
     * returns a random time in future that is {@link #WAIT_TIME} from now.
     * @return The sim time when node should ask the next time for a path
     */
    @Override
    public double nextPathAvailable() {
        if(this.host.getChargingStatus() == -2) {
            this.host.setChargingStatus(0);
            this.jmax = (int) Math.floor(this.minWaitTime/(7200.0));// 从秒换成时间段（2小时, 0-11)
        }

        return  SimClock.getTime() + minWaitTime;
    }

    // 查询选择充电站和最短路径
    @Override
    public Path getPath() {
        if (this.host.getChargingStatus() != 0) {
            return null;
        }
        // 生成一个速度，这个速度只在这一段path里面有用。下一段还会重新生成。or： 在初始化的时候一起生成
        double speed = generateSpeed(); // (m/s)
        // 生成一个空的path用来存路线
        Path p = new Path(speed);
        // 用poi的函数随机选一个目的地。
        MapNode to = pois.selectDestination();

        // 访问静态字段
        double currentTime = SimClock.getTime();
        double arriveTime, MinArriveTime = 0;
        int MinIndex = -1;
        double MinCost = -1;// 初始化为-1

        MapNode stationNode;
        List<MapNode> nodePath1 = null, nodePath2 = null,
                MinNodePath1 = null, MinNodePath2 = null;

        // get all the hosts of the word
        List<DTNHost> hosts = host.getWorld().getHosts();

        double dist1, dist2;// the total distance of choosing a station， (m)
        double waitingTime, cost, roadTime;// the price of the charging option

        MovementModel MM;

        // 遍历所有的host，查询
        for (int i = 0; i < StationMovement.getL(); i++) {
            // 获取host的类型，对所有充电站进行查询，并获得最低总成本充电站
            // TODO: 如果在setting里面按顺序写，就不用全部遍历host，节约时间
            // TODO: 考虑要不要购买充电权，那就是返回预计等待时间和价格，相对比。

            MM = hosts.get(i).getMovement();
            if (MM instanceof StationMovement) {
//                (StationMovement) MM.
                // 返回充电站的地点
                stationNode = ((StationMovement) MM).getMapNode();


                // 得到从这里到充电站以及从充电站到目的地的路线和总路程
                nodePath1 = pathFinder.getShortestPath(lastMapNode, stationNode);
                nodePath2 = pathFinder.getShortestPath(stationNode, to);
                dist1 = pathFinder.getPathDistance(nodePath1);
                dist2 = pathFinder.getPathDistance(nodePath2);


                // 计算到达充电站时间, 现在的时间加上第一段时间
                arriveTime = dist1 / speed + currentTime;

                // 发送查询请求,返回预计等待时间
                waitingTime = ((StationMovement) MM).getWaitingTime(arriveTime);

                // 计算总成本并存储。排队时间成本加上两段的时间成本
                // TODO : 先考虑简单的，不考虑时间成本。这样看看分布。后面再看看平均多少行驶时间，多少钱
                /**
                 * 在这个地方调整参数，就是三种选择：排队时间，行驶时间，路程时间。
                 */
//                // 行程最短 MTD
//                cost =   (-beta_TT) * (waitingTime + (dist1 + dist2) / speed) / (60.0 * 60.0);

                // 排队最短 MQT,这里的时间单位为小时
//                cost =   (-beta_TT) * (waitingTime+ 0.01 * (dist1 + dist2) / speed) / (60.0 * 60.0);


//                // 路程最短 MRT
                cost =   (-beta_TT) * (  (dist1 + dist2) / speed) / (60.0 * 60.0);


                roadTime = (dist1 + dist2) / speed / 60.0;//以分钟为单位

                // 更新最低成本
                if (i == 0) {
                    MinCost = cost;
                    this.TT = roadTime;//等待时间转成分钟

                    MinIndex = i;
                    MinArriveTime = arriveTime;

                    MinNodePath1 = nodePath1;
                    MinNodePath2 = nodePath2;

                } else if(cost < MinCost) {
                    MinCost = cost;
                    this.TT = roadTime;//等待时间转成分钟

                    MinIndex = i;
                    MinArriveTime = arriveTime;

                    MinNodePath1 = nodePath1;
                    MinNodePath2 = nodePath2;
                }
            }
        }

        // 选择总成本最低的充电站，购买.(如果是-1表示没有找到充电站）
        if (MinIndex != -1) {
            // 选择成本最低的充电站,设置关联，并购买充电权
            this.host.setChargingHost(hosts.get(MinIndex));
            boolean ok = ((StationMovement) hosts.get(MinIndex).getMovement()).reserve(this.host, MinArriveTime);

            // 设置cost，此后会report
            this.host.setCost(this.TT, 0.0, 0.0, this.beta_TT, this.jmax);

        }


        // this assertion should never fire if the map is checked in read phase
        assert MinNodePath1.size() > 0 : "No path from " + lastMapNode + " to " +
                to + ". The simulation map isn't fully connected";
        for (MapNode node : MinNodePath1) { // create a Path from the shortest path
            p.addWaypoint(node.getLocation());
        }


        assert MinNodePath2.size() > 0 : "No path from " + lastMapNode + " to " +
                to + ". The simulation map isn't fully connected";
        for (int i = 1; i < MinNodePath2.size(); i++) { // create a Path from the shortest path

            p.addWaypoint(MinNodePath2.get(i).getLocation());

        }

        lastMapNode = to;
        return p;
    }

    @Override
    public QueryTime replicate() {
        return new QueryTime(this);
    }
}
