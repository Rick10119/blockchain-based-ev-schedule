package movement;

import core.DTNHost;
import core.Settings;
import core.SimClock;
import movement.map.DijkstraPathFinder;
import movement.map.MapNode;
import movement.map.PointsOfInterest;

import java.util.List;
import java.util.Random;

public class ChangeTime extends MapBasedMovement {

    /**
     * the Dijkstra shortest path finder
     */
    private DijkstraPathFinder pathFinder;
    /**
     * Points Of Interest handler
     */
    private PointsOfInterest pois;
    /**
     * The special setting of the EV
     */
    // TODO: 后面可以把这个时间成本随机化。还有就是位置的初始化
    private double beta_TT ;// 每小时的时间成本（￥），北京市每小时24元
    private double beta_SDE;// 提前一个时段出发的成本（取相反数）
    private double beta_SDL;// 延后一个时段出发的成本
    private double TT;// 总共的时间
    private int jmax;// 选择的时间段


    // 构造器和父类一样。需要覆盖：选择路径的方法

    /**
     * Creates a new movement model based on a Settings object's settings.
     * 涉及到电动汽车参数设置
     *
     * @param settings The Settings object where the settings are read from
     */
    public ChangeTime(Settings settings) {
        super(settings);

        this.pathFinder = new DijkstraPathFinder(getOkMapNodeTypes());
        this.pois = new PointsOfInterest(getMap(), getOkMapNodeTypes(),
                settings, rng);
        this.backAllowed = true;

        Random rng = new Random();// 产生随机数
        this.beta_SDL = -24.0 * rng.nextDouble();
        this.beta_SDE = -24.0 * rng.nextDouble();
        this.beta_TT = -12.0 -24.0 * rng.nextDouble();
    }

    /**
     * Copy constructor.
     *
     * @param mbm The ChargingMovement prototype to base
     *            the new object to
     */
    public ChangeTime(ChangeTime mbm) {
        super(mbm);
        this.pathFinder = mbm.pathFinder;
        // TODO: 这个初始化的方式要和sp一样（在settings里面）
        this.pois = mbm.pois;
        this.beta_TT = mbm.beta_TT;
        this.beta_SDE = mbm.beta_SDE;
        this.beta_SDL = mbm.beta_SDL;
    }

    /**
     * Returns a sim time when the next path is available. This implementation
     * returns a random time in future that is {@link #WAIT_TIME} from now.
     * @return The sim time when node should ask the next time for a path
     */
    @Override
    public double nextPathAvailable() {
        if(this.host.getChargingStatus() != -2) {
            return  SimClock.getTime() + generateWaitTime();
        }
        // 应该改成在新的时段里面均匀分布。这是在t=0决定的，所以应该当做SimClock.getTime() = 0;(我试过了，是真的)
        return  SimClock.getTime() + getChangedTime();
    }

    /** 返回行程变更时间，用于决定实际出发时间。 */
    private double getChangedTime() {

        // 针对初始化的修正
        if(null == this.host) {
            return 0.0;
        }

        // 原定出发时间。不考虑到充电站的时间
        int j0 = (int) Math.floor(this.minWaitTime/(7200.0));// 从秒换成时间段（2小时, 0-11)

        // 通过充电站查询预测的价格、排队时间。先返回充电站句柄，然后查询。所有充电站都一样，因此用0号的
        StationMovement MM = (StationMovement)this.host.getScenario().getHosts().get(0).getMovement();

        // 最多允许前后变动两个时间段,获得最小的lambdaK
        int jmax = j0;//变动的时间段，默认为j0
        double utility;
        // 初始化用户效用函数
        double maxUtility = calculateUtility(MM.getMeanWaitTime(j0), MM.queryPrice(j0), 0) ;


        for(int j = j0 - 2;j <= j0 + 2;j++) {
            // 变动后的时间
            if(j < 0 || j >= 12) {
                //超出查找范围
                continue;
            }

            // 根据查询计算对应的效用函数
            utility = calculateUtility(MM.getMeanWaitTime(j), MM.queryPrice(j), j - j0);
//            System.out.println("j0: " + j0 + " jmax: " + jmax + " newTime: ");
//            System.out.println("排队时间: " + MM.getMeanWaitTime(j) + " 价格: " + MM.queryPrice(j));

            // 查询对应的lambda值
            if(utility > maxUtility ) {
                maxUtility = utility;
                jmax = j;
            }
        }

        // 在这里报告最大的Utility对应的价格
        this.host.setPrice(MM.queryPrice(jmax));
        // 或者只查询排队时间，并记录。这是用来对比没有价格的情形的。
//        this.host.setPrice(MM.getMeanWaitTime(j0 + jmax));

        // 购买时段充电权
        this.jmax = jmax;

        MM.buy(jmax);

        this.host.setChargingStatus(0);

        return jmax * 7200.0 + rng.nextDouble() * 7200;
    }

    /** 计算用户效用 */
    private double calculateUtility(double WaitTime, double Price, int deltaj) {
        // 时间单位转换为小时
        double SDE, SDL, TT;

        // 计算改变量
        SDL = Math.max(deltaj, 0);
        SDE = Math.max(-deltaj, 0);
        TT = WaitTime/(60.0);

        double utility = 2.0 * beta_SDE * SDE + 2.0 * beta_SDL * SDL + beta_TT * TT - Price * this.host.getEnergyToCharge();

        return  utility;

    }

    // 查询选择充电站和最短路径
    @Override
    public Path getPath() {
        if (this.host.getChargingStatus() != 0) {
            return null;
        }
        // 生成一个速度，这个速度只在这一段path里面有用。下一段还会重新生成。or： 在初始化的时候一起生成
        double speed = generateSpeed(); // (m/s)
        // 生成一个空的path用来存路线
        Path p = new Path(speed);
        // 用poi的函数随机选一个目的地。
        MapNode to = pois.selectDestination();

        // 访问静态字段
        double currentTime = SimClock.getTime();
        double arriveTime, MinArriveTime = 0;
        int MinIndex = -1;
        double MinCost = -1;// 初始化为-1

        MapNode stationNode;
        List<MapNode> nodePath1 = null, nodePath2 = null,
                MinNodePath1 = null, MinNodePath2 = null;

        // get all the hosts of the word
        List<DTNHost> hosts = host.getWorld().getHosts();

        double dist1, dist2;// the total distance of choosing a station， (m)
        double waitingTime, cost, roadTime;// the price of the charging option

        MovementModel MM;

        // 遍历所有的host，查询
        for (int i = 0; i < StationMovement.getL(); i++) {
            // 获取host的类型，对所有充电站进行查询，并获得最低总成本充电站

            MM = hosts.get(i).getMovement();
            if (MM instanceof StationMovement) {
                // 返回充电站的地点
                stationNode = ((StationMovement) MM).getMapNode();


                // 得到从这里到充电站以及从充电站到目的地的路线和总路程
                nodePath1 = pathFinder.getShortestPath(lastMapNode, stationNode);
                nodePath2 = pathFinder.getShortestPath(stationNode, to);
                dist1 = pathFinder.getPathDistance(nodePath1);
                dist2 = pathFinder.getPathDistance(nodePath2);


                // 计算到达充电站时间, 现在的时间加上第一段时间
                arriveTime = dist1 / speed + currentTime;

                // 发送查询请求,返回预计等待时间
                waitingTime = ((StationMovement) MM).getWaitingTime(arriveTime);

                // 计算总成本并存储
                cost =  - beta_TT * (waitingTime + (dist1 + dist2) / speed) / (60.0 * 60.0);

                //存储路程时间
                roadTime = (dist1 + dist2) / speed / 60.0;//以分钟为单位


                // 更新最低成本
                if (i == 0) {
                    MinCost = cost;
                    this.TT = roadTime;//等待时间转成分钟

                    MinIndex = i;
                    MinArriveTime = arriveTime;

                    MinNodePath1 = nodePath1;
                    MinNodePath2 = nodePath2;

                } else if(cost < MinCost) {
                    MinCost = cost;
                    this.TT = roadTime;//等待时间转成分钟

                    MinIndex = i;
                    MinArriveTime = arriveTime;

                    MinNodePath1 = nodePath1;
                    MinNodePath2 = nodePath2;
                }
            }
        }

        // 选择总成本最低的充电站，购买.(如果是-1表示没有找到充电站）
        if (MinIndex != -1) {
            // 选择成本最低的充电站,设置关联，并预约充电
            this.host.setChargingHost(hosts.get(MinIndex));
            boolean ok = ((StationMovement) hosts.get(MinIndex).getMovement()).reserve(this.host, MinArriveTime);

            // 设置cost
            this.host.setCost(this.TT, this.beta_SDL, this.beta_SDE, this.beta_TT, this.jmax);
        }


        // this assertion should never fire if the map is checked in read phase
        assert MinNodePath1.size() > 0 : "No path from " + lastMapNode + " to " +
                to + ". The simulation map isn't fully connected";
        for (MapNode node : MinNodePath1) { // create a Path from the shortest path
            p.addWaypoint(node.getLocation());
        }


        assert MinNodePath2.size() > 0 : "No path from " + lastMapNode + " to " +
                to + ". The simulation map isn't fully connected";
        for (int i = 1; i < MinNodePath2.size(); i++) { // create a Path from the shortest path

            p.addWaypoint(MinNodePath2.get(i).getLocation());

        }

        lastMapNode = to;
        return p;
    }

    @Override
    public ChangeTime replicate() {
        return new ChangeTime(this);
    }
}
