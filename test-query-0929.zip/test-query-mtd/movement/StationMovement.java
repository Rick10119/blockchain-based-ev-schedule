package movement;

import core.Coord;
import core.DTNHost;
import core.Settings;
import movement.map.MapNode;
import movement.map.PointsOfInterest;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import core.SimClock;
import util.ActivenessHandler;


/**
 *
 *
 */
public class StationMovement extends MapBasedMovement {
    /** Per node group setting for setting the location ({@value}) */
    public static final String LOCATION_S = "nodeLocation";
    private Coord loc; /** The location of the nodes */

    // Field of charging station states, see the chargingoption.go: StationState struct


    /** Queue of evs */
    private StationQueue stationQueue;
    private ActivenessHandler ah;

    // static变量对所有实例都一样：
    private static final double nofSlots = 6.0;// Number of charging slots
    private static final int nofFrames = 12;    //number of time nofFrames
    private static final double lofFrames = 120.0;    // 时间段的长度，分钟
    private static double nofStations = 10.0;      //number of charging stations
    private static double tau = 30.0;      //平均充电时间,min
    private static final double beta_t = 24.0 / 60.0;         // average unit cost of time(per min), used for calculating co price, 从小时转化为分钟
    private static final double mu = 4.0;        // average charging rate, used for calculating co price
    private static final double sigma2a = 1.0;
    private static final double sigma2c = 0.1481;
    private static final double c = nofSlots * nofStations;

    /** node's wait time CSV (min, max) -setting id ({@value})*/
    public static final String NOFHOSTS = "nrofHosts";
    public static final String BASE_PRICE = "basePrice";


    private static double[] Lambda_b = new double[nofFrames];
    private static double[] CO_price = new double[nofFrames];
    private static double[] Base_price = new double[nofFrames];
    private static double[] meanWaitTime = new double[nofFrames];



    /** default setting for lambdaK */
    public static final double DEF_NOFHOSTS = 10.0;// 不读的吗？


    /**
     * Creates a new movement model based on a Settings object's settings.
     * Initiate the state of the charging station
     * @param s The Settings object where the settings are read from
     */
    public StationMovement(Settings s) {
        super(s);

        ah = new ActivenessHandler(s);

        // 对基础价格的设定
        if (s.contains(BASE_PRICE)) {
            Base_price = s.getCsvDoubles(BASE_PRICE, nofFrames);
        } else {
            Base_price = new double[nofFrames];// 外部设定的价格，默认设成0
        }

        // 读取nofHosts的设定
        if (s.contains(NOFHOSTS)) {
            nofStations = s.getCsvDoubles(NOFHOSTS, 1)[0];
        } else {
            nofStations = DEF_NOFHOSTS;
        }

        this.loc = getInitialLocation();

        // initiate the variables, the lambda and price
        for(int T = 0;T < nofFrames;T ++) {
            Lambda_b[T] = 0;
            CO_price[T] = 0;
            meanWaitTime[T] = 0;
            // calculate the price of time slot T
        }

        // 队列的初始化
        stationQueue = new StationQueue(this.host);

        s.restoreNameSpace();

    }

    /**
     * Returns the only location of this movement model
     * @return the only location of this movement model
     * 如果改这个，就可以随机生成初始位置
     */
//    @Override
//    public Coord getInitialLocation() {
//        return loc;
//    }

    /**
     * Returns a (random) coordinate that is a MapNodes
     * 只是上面那个函数不修正地址,用于充电站地址的初始化；
     */
    public Coord getInitialLocation() {
        List<MapNode> nodes = super.getMap().getNodes();
        MapNode n;
        Coord placement;


        // choose a random node (from OK types if such are defined)
        do {
            n = nodes.get(rng.nextInt(nodes.size()));
        } while (super.getOkMapNodeTypes() != null && !n.isType(super.getOkMapNodeTypes()));

        placement = n.getLocation().clone();

        this.lastMapNode = n;


        return placement;
    }

    /**
     * Return the price, called by ChargingMovement to make decision
     * 对充电站而言，就是和go一样的体系：离散时间。转换放到ChargingMovement中做。
     * @param T arrive time
     * @return the price of a given time duration
     */
    public double queryPrice(int T) {

        if(T < 0 || T >= nofFrames){
            System.out.println("查询T超出范围");
            return 0;
        }

        // 价格是到达时段基础价格加上排队考虑的价格
        return Base_price[T] + CO_price[T];
    }

    /** 返回估计的排队时间 , Algo2 */
    public double getWaitingTime(double arriveTime) {

        if(this.stationQueue.getHost()==null) {
            this.stationQueue.setHost(this.host);
        }

        return this.stationQueue.getWaitTime(arriveTime);
    }

    /** 根据时间段返回充电站存储的平均排队时间 */
    public double getMeanWaitTime(int j) {
        if(j < 0 || j >= nofFrames){
            System.out.println("查询平均排队时间：err:时间段 j 超出范围");
            return 0;
        }
        return meanWaitTime[j];
    }

    /**
     * 如果有车辆购买充电权，要相应地修改充电站状态，主要是lambda_b和price
     * @param j time frame queried
     * @return 购买成功则返回 true
     */
    public boolean buy(int j) {
        // TODO: to record the revenue of the charging station
        // 每个时段，更新预订车辆数目，并且相应修改价格。要注意不能超售
        // set the lambda and price


            // 没有超额预约，那么修改状态
            Lambda_b[j] = Lambda_b[j] + 1;
            double rate = 1.0; // 每分钟的充电速率，60kw -> 1kwh/min
            double lambda = Lambda_b[j] / lofFrames; //到达率


            // 如果已预约满了，把价格调成很大（100）
            if(Lambda_b[j] >= c * mu - 1.0) {

                CO_price[j] = 1000;

            } else {
                // calculate the price of time frame j
                double rho = lambda * tau / c;
//                System.out.println("lambda_b: " + Lambda_b[j] + " 价格: " + CO_price[j]);

//                System.out.println("c: "+ c);

                // 平均排队时间：min
                meanWaitTime[j] = tau / c * (rho /(1 - rho)) * (sigma2c + sigma2a) / 2;
                // 充电权价格：每单位电量（kw）
                CO_price[j] =  beta_t * rho/(1 - rho)/(1 - rho) * (sigma2c + sigma2a) / 2 /(c * rate);


            }
        return true;
    }

    /**
     * 保存预约信息，这是下一步要做的
     * @return
     */
    public boolean reserve(DTNHost host, double arriveTime) {
        return this.stationQueue.reserve(host, arriveTime);
    }

    /**
     * 返回充电站的坐标对应的MapNode，这样可以在Dijkstra算法中使用。
     */
    public MapNode getMapNode() {
        return this.lastMapNode;
    }

    /** 返回充电站的队列句柄，方便在host中调用以更新队列 */
    public StationQueue getStationQueue() {
        return this.stationQueue;
    }

    /** 返回充电站数量 */
    public static int getL() {
        return (int) Math.round(nofStations);
    }

    /**
     * Copy constructor. 用于replicate()调用，只调用一次吗？不知道。最好是每次都完全复制
     * @param sm The StationMovement prototype
     */
    public StationMovement(StationMovement sm) {
        super(sm);
        this.loc = sm.loc;
        this.stationQueue = sm.getStationQueue().replicate();
    }



    /**
     * Returns a single coordinate path (using the only possible coordinate)
     * @return a single coordinate path
     */
    @Override
    public Path getPath() {
        Path p = new Path(0);
        p.addWaypoint(loc);
        return p;
    }

    @Override
    public double nextPathAvailable() {
        return Double.MAX_VALUE;	// no new paths available
    }

    @Override
    public StationMovement replicate() {
        return new StationMovement(this);
    }

}
