package param;

import java.io.*;
import java.util.Random;
import java.util.Scanner;

public class QueryTimeSet {

    private final static String SETTING_FILE_PATH = "./param/newSetting.txt";
    private final static String LAMBDA_FILE_PATH = "./param/lambdaK.txt";
    private final static String PRICE_FILE_PATH = "./param/basePrice.txt";

    /**
     * common rng for all movement models in the simulation
     * 这个文件生成多充电站时候的情形，也就是在ParameterSet的基础上，多个充电站，而且相应增加lambda
     */
    final String DELIMITER = "\t";
    // 文件和buffer定义

    /**
     * 仿真、步长、车辆产生率
     */
    static File file_setting = new File(SETTING_FILE_PATH);
    static File file_lambda = new File(LAMBDA_FILE_PATH);
    static File file_price = new File(PRICE_FILE_PATH); // 基础价格
    static BufferedWriter bw = null;
    static int nofFrames = 12;//number of time slots, 12 for default
    static int nofStations;
    static String movementModel;
    static double[] LambdaK;
    static double[] Base_price;


    public static void main(String[] args) throws IOException {

        //从命令行读取参数

        nofFrames =  Integer.parseInt(args[0]); //仿真时段数；
        LambdaK = new double[nofFrames];
        Base_price = new double[12]; // default to be 12

        nofStations = Integer.parseInt(args[1]);//充电站个数

        movementModel = args[2];//运动类型

        try {
            // 打开setting文件
            bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file_setting), "UTF-8"));

            //写入仿真总时间（s）,在设定的基础上延后两小时？不影响后面的排队时间的(26h)
            WriteDataToFile(bw, "Scenario.endTime = " + (7200 * nofFrames + 7200));

            // 写入price
            WritePrice();

            // 写入充电站个数
            WriteDataToFile(bw, "Group1.nrofHosts = " + nofStations);

            // 写入movement的类型
            WriteDataToFile(bw, "Group.movementModel = " + movementModel);

            // 写入车辆开始运行时间,参数为前面输入的lambda
            WriteBeginningTime();

            // 处理异常及关闭文件
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != bw) {
                bw.close();
            }
        }
    }


    /**
     * 根据参数写入车辆的启动时间，用于模拟泊松过程的车辆产生。
     *
     * @throws IOException
     */
    public static void WriteBeginningTime() throws IOException {

        Random rng = new Random();// 产生随机数

        Scanner scanner = new Scanner(file_lambda);
        for (int i = 0; i < nofFrames; i++) {
            LambdaK[i] = scanner.nextDouble();
        }

        String str;
        int beginTime;// 以秒为单位

        int groupIndex = 1;//现在已经有1个组(cs),从第二个组开始设置

//        for (int j = 1; j <= nofFrames; j ++) {
//
//            for (int i = 1; i <= Math.round(LambdaK[j - 1]);i ++) {
//                beginTime = 7200 * (j-1) + (int)(Math.floor(7200 * rng.nextDouble()));
//
//                groupIndex++;
//
//                str = String.format("Group%d.waitTime = %d, %d", groupIndex, beginTime, beginTime);
//                WriteDataToFile(bw, str);
//
//            }
//
//
//        }
        for (int time = 0; time < 7200 * nofFrames; time++) {
            double tis = rng.nextDouble();

            // T 属于哪个时段，（总共12个）
            int j = (int)Math.floor(time / 7200.0);
            // 读取lambda
            double lambda = LambdaK[j];
            // 二项分布下，产生汽车概率为 lambda
            // 平均一秒钟产生车辆的概率为 lambda / timeInterval / 60
            if (tis < lambda / 7200.0) { //产生车辆

                groupIndex++;

                str = String.format("Group%d.waitTime = %d, %d", groupIndex, time, time);
                WriteDataToFile(bw, str);

            }
        }
//        str = String.format("MovementModel.rngSeed = %d", (int)(rng.nextDouble() * 10000));
//
//        WriteDataToFile(bw, str);


        // 输入总共组的个数
        str = String.format("Scenario.nrofHostGroups = %d", groupIndex);

        WriteDataToFile(bw, str);

    }


    public static void WritePrice() throws IOException {
        // 要读两个lambda，一个用来生成汽车，一个用来给充电站作为预测数据要写进文件


        Scanner scanner1 = new Scanner(file_price);
        for (int i = 0; i < nofFrames; i++) {
            Base_price[i] = scanner1.nextDouble();
        }

        String str = "Group.basePrice = ";

        for (int time = 0; time < 12; time++) {

                if(time == 0){
                    str = str + " "+Base_price[time];
                } else {
                    str = str + ", "+Base_price[time];

                }

        }
        WriteDataToFile(bw, str);
    }

    /**
     * 将格式化的数据写入文件中file
     *
     * @throws IOException
     */
    public static void WriteDataToFile(BufferedWriter bw, String str) throws IOException {

        //写入setting的内容
        bw.write(str);  // 将数据写入文件中
        bw.newLine();        // 新建一个换行符
        bw.flush();
    }
}
