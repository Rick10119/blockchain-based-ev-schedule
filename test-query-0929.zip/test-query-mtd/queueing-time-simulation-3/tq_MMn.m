function t = tq_MMn(ro, n)


ro = ro;% utility
ro1 = ro * n;
mu = 1.5;

% M/M/n
% �����׳� expand(factorial(sym(1000)))
  
    temp_k = zeros(1, n);
    for k = 0:n-1
        temp_k(k+1) = ro1^k/(expand(factorial(sym(k))));
    end
       
    p0 = 1/ (sum(temp_k)+ ro1^n/expand(factorial(sym(n)))/(1-ro));
    W_q_MMn = 45 * ro1^n*p0/(mu*n*expand(factorial(sym(n)))*(1-ro)^2);
    
    t = W_q_MMn;

end

