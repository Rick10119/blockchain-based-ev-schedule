
% to give the J
% ����3���վ�ĸ������ߣ�ֻ���Ǿ��롢mmnm����ֵ��mm9n9m����
clc;clear;
% m = 108; % max cars
n = 60 * 9; % slots
% R = 30; % revenue
w = 6;
J = 0.02*5/9;
mu = 1.5;
t0 = 45;
nofStation = 90;

t_davidson = [];
t_MMn = [];
% t_MMnm = [];
h = 0.1;


%%
for lambda = (0.1:0.1:0.9)*nofStation*6*mu

ro1 = lambda/mu;
    ro = lambda / mu/n;% utility
    

    % Davidson
    t_davidson = [t_davidson;1/mu + 1/mu * J * ro/(1 - ro)];

    
    % M/M/n
  
    temp_k = zeros(1, n);
    for k = 0:n-1
        temp_k(k+1) = ro1^k/(factorial(k));
    end
       
    p0 = 1/ (sum(temp_k)+ ro1^n/factorial(n)/(1-ro));
    W_q_MMn = ro1^n*p0/(mu*n*factorial(n)*(1-ro)^2);
    
    t_MMn = [t_MMn;1/mu + W_q_MMn];
    
    
%     %M/M/n/m  
%     p0 = 1/ (sum(temp_k)+ ro1^n/factorial(n)/(1-ro)*(1-ro^(m-n+1)));
%     temp_pk = zeros(1,n);
%     for k = 0:n-1
%         temp_pk(k+1) = (n-k)*ro1^k/factorial(k)*p0;
%     end
%     W_q_MMnm = n^n*ro^(n+1)*p0*(1-(m-n+1)*ro^(m-n)+(m-n)*ro^(m-n+1))/(factorial(n)*(1-ro)^2*mu*(n-sum(temp_pk)));
%     
%     t_MMnm = [t_MMnm;1/mu + W_q_MMnm*0.8];
    
end

%% ��ͼ

ro = 0.1:0.1:0.9;
linewidth = 1.3;

roadTime_tj = [];
queueTime_tj = [];
%% 9վ��ֱ��ȥ����ĳ��վ-df
load('sim-l9-df-3s.mat');
roadTime_tj = [roadTime_tj;expectRoadTime];
queueTime_tj = [queueTime_tj;expectTime];

%% ֻ������Ŷ�ʱ��-mqt

load('sim-l9-mqt-3s.mat');
roadTime_tj = [roadTime_tj;expectRoadTime];
queueTime_tj = [queueTime_tj;expectTime];
%% ��queryTime��9վ�� ����г�ʱ��-mtd

load('sim-l9-mtd-3s.mat');
roadTime_tj = [roadTime_tj;expectRoadTime];
queueTime_tj = [queueTime_tj;expectTime];







%%
total_time = roadTime_tj + queueTime_tj;
A = [];
 for i = 1:3
    A = [A;[queueTime_tj(i,1)-30,roadTime_tj(i,1)]];
 end

for i = 1:3
    A = [A;[queueTime_tj(i,2)-30,roadTime_tj(i,2)]];
end
 A = [A;[30*0.054, 0]];
A=reshape(A,[7 1 2]);
    x={'MRT','MQT','MTD','MRT','MQT','MTD',"LB"} ;
    plotBarStackGroups(A,x);
    legend("�Ŷ�ʱ��","��ʻʱ��");
    x1 = xlabel('��һ���������ֱ�Ϊ��[0.5, 0.9](#)','FontSize',18);          %����������tex����
y1 = ylabel('ƽ��ʱ��(����)','FontSize',18);
set(gca, "XGrid", "on");
set(gca, "YGrid", "on");
set(gca,'linewidth',1.5,'fontsize',18);
hold on;
saveas(gcf,'total-time-90.jpg'); %���浱ǰ���ڵ�ͼ��66666666




